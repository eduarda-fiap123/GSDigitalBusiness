package br.com.fiap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import br.com.fiap.model.Visitante;

public class VisitanteDao {
	EntityManagerFactory factory = 
			Persistence.createEntityManagerFactory("progamer-persistence-unit");
	EntityManager manager = factory.createEntityManager();
	
	public void create(Visitante visitante) {
		manager.getTransaction().begin();
		manager.persist(visitante);
		manager.getTransaction().commit();
		
		manager.clear();
		
	}
	
	public List<Visitante> listAll() {
		TypedQuery<Visitante> query = 
				manager.createQuery("SELECT u FROM Visitante u", Visitante.class);
		return query.getResultList();
	}
	
	/*
	public boolean exist(Visitante visitante) {
		// TODO Auto-generated method stub
		String jpql = "SELECT u FROM visitante u WHERE nome=:nome AND cpf=:cpf";
		TypedQuery<Visitante> query = manager.createQuery(jpql, Visitante.class);
		query.setParameter("Nome", visitante.getName());
		query.setParameter("CPF", visitante.getCpf());
		
		try {
			query.getSingleResult();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}
	}
	*/
}	
